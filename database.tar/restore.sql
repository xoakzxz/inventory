--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.2
-- Dumped by pg_dump version 9.6.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

DROP INDEX public.item_item_id_idx;
DROP INDEX public.index_user_id;
DROP INDEX public.index_type;
DROP INDEX public.index_name1;
DROP INDEX public.index_name;
DROP INDEX public.index_item_slot_2;
DROP INDEX public.index_item_slot_1;
DROP INDEX public.index_gold;
DROP INDEX public.index_cost;
ALTER TABLE ONLY public."user" DROP CONSTRAINT user_pkey;
ALTER TABLE ONLY public."user" DROP CONSTRAINT unique_user_id;
ALTER TABLE ONLY public.item DROP CONSTRAINT item_pkey1;
ALTER TABLE ONLY public.inventory DROP CONSTRAINT item_pkey;
ALTER TABLE ONLY public.item DROP CONSTRAINT item_item_id_key;
DROP TABLE public."user";
DROP TABLE public.item;
DROP TABLE public.inventory;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: inventory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE inventory (
    user_id integer NOT NULL,
    item_id integer NOT NULL,
    amount integer NOT NULL
);


ALTER TABLE inventory OWNER TO postgres;

--
-- Name: item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE item (
    item_id integer NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    cost integer NOT NULL
);


ALTER TABLE item OWNER TO postgres;

--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "user" (
    user_id integer NOT NULL,
    name text NOT NULL,
    gold integer NOT NULL
);


ALTER TABLE "user" OWNER TO postgres;

--
-- Data for Name: inventory; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2145.dat

--
-- Data for Name: item; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2147.dat

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2146.dat

--
-- Name: item item_item_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY item
    ADD CONSTRAINT item_item_id_key UNIQUE (item_id);


--
-- Name: inventory item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY inventory
    ADD CONSTRAINT item_pkey PRIMARY KEY (user_id, item_id);


--
-- Name: item item_pkey1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY item
    ADD CONSTRAINT item_pkey1 PRIMARY KEY (item_id);


--
-- Name: user unique_user_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "user"
    ADD CONSTRAINT unique_user_id UNIQUE (user_id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (user_id);


--
-- Name: index_cost; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_cost ON item USING btree (cost);


--
-- Name: index_gold; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_gold ON "user" USING btree (gold);


--
-- Name: index_item_slot_1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_item_slot_1 ON inventory USING btree (item_id);


--
-- Name: index_item_slot_2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_item_slot_2 ON inventory USING btree (amount);


--
-- Name: index_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_name ON "user" USING btree (name);


--
-- Name: index_name1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_name1 ON item USING btree (name);


--
-- Name: index_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_type ON item USING btree (type);


--
-- Name: index_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX index_user_id ON inventory USING btree (user_id);


--
-- Name: item_item_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX item_item_id_idx ON item USING btree (item_id);


--
-- PostgreSQL database dump complete
--

